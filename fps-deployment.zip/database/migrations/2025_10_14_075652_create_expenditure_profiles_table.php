<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('expenditure_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->decimal('monthly_housing', 10, 2)->default(0.00);
            $table->decimal('monthly_utilities', 10, 2)->default(0.00);
            $table->decimal('monthly_food', 10, 2)->default(0.00);
            $table->decimal('monthly_transport', 10, 2)->default(0.00);
            $table->decimal('monthly_insurance', 10, 2)->default(0.00);
            $table->decimal('monthly_loans', 10, 2)->default(0.00);
            $table->decimal('monthly_discretionary', 10, 2)->default(0.00);
            $table->decimal('total_monthly_expenditure', 10, 2)->default(0.00);
            $table->timestamps();

            $table->index('user_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('expenditure_profiles');
    }
};
