<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('disability_policies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('provider');
            $table->string('policy_number')->nullable();
            $table->decimal('benefit_amount', 10, 2);
            $table->enum('benefit_frequency', ['monthly', 'weekly'])->default('monthly');
            $table->integer('deferred_period_weeks');
            $table->integer('benefit_period_months')->nullable();
            $table->decimal('premium_amount', 10, 2);
            $table->enum('premium_frequency', ['monthly', 'quarterly', 'annually'])->default('monthly');
            $table->string('occupation_class')->nullable();
            $table->date('policy_start_date');
            $table->integer('policy_term_years')->nullable();
            $table->enum('coverage_type', ['accident_only', 'accident_and_sickness'])->default('accident_and_sickness');
            $table->timestamps();

            $table->index('user_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('disability_policies');
    }
};
