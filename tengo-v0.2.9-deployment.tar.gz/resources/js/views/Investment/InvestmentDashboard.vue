<template>
  <component :is="isEmbedded ? 'div' : 'AppLayout'">
    <div class="investment-dashboard py-6">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <!-- Breadcrumb (only show when not embedded) -->
      <nav v-if="!isEmbedded" class="mb-6" aria-label="Breadcrumb">
        <ol class="flex items-center space-x-2 text-sm">
          <li>
            <router-link to="/dashboard" class="text-gray-500 hover:text-gray-700">
              Home
            </router-link>
          </li>
          <li>
            <svg
              class="w-4 h-4 text-gray-400"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd"
              />
            </svg>
          </li>
          <li>
            <span class="text-gray-900 font-medium">Investment</span>
          </li>
        </ol>
      </nav>

      <!-- Header (only show when not embedded) -->
      <div v-if="!isEmbedded" class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-2">Investment Portfolio</h1>
        <p class="text-gray-600">
          Monitor your portfolio performance, analyse holdings, and optimise your investment strategy
        </p>
      </div>

      <!-- Loading State -->
      <div v-if="loading" class="flex justify-center items-center py-12">
        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>

      <!-- Error State -->
      <div
        v-else-if="error"
        class="bg-red-50 border-l-4 border-red-500 p-4 mb-6"
      >
        <div class="flex">
          <div class="flex-shrink-0">
            <svg
              class="h-5 w-5 text-red-400"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                clip-rule="evenodd"
              />
            </svg>
          </div>
          <div class="ml-3">
            <p class="text-sm text-red-700">{{ error }}</p>
          </div>
        </div>
      </div>

      <!-- Main Content -->
      <div v-else :class="isEmbedded ? 'investment-embedded' : 'bg-white rounded-lg shadow'">
        <!-- Tab Navigation -->
        <div :class="isEmbedded ? 'border-b border-gray-200' : 'border-b border-gray-200 bg-white'">
          <nav class="-mb-px flex overflow-x-auto" aria-label="Tabs">
            <button
              v-for="tab in tabs"
              :key="tab.id"
              @click="activeTab = tab.id"
              :class="[
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300',
                'whitespace-nowrap py-2 px-2 border-b-2 font-medium text-sm transition-colors duration-200',
              ]"
            >
              {{ tab.label }}
            </button>
          </nav>
        </div>

        <!-- Tab Content -->
        <div :class="isEmbedded ? '' : 'p-6'">
          <!-- Portfolio Overview Tab -->
          <PortfolioOverview
            v-if="activeTab === 'overview'"
            @open-add-account-modal="openAddAccountModal"
          />

          <!-- Accounts Tab -->
          <Accounts
            v-else-if="activeTab === 'accounts'"
            ref="accountsComponent"
            @view-holdings="handleViewHoldings"
          />

          <!-- Holdings Tab -->
          <Holdings
            v-else-if="activeTab === 'holdings'"
            :selected-account-id="selectedAccountId"
            @clear-filter="clearAccountFilter"
          />

          <!-- Performance Tab (Enhanced with Phase 2.7) -->
          <div v-else-if="activeTab === 'performance'">
            <Performance @navigate-to-tab="navigateToTab" />
            <div class="mt-8">
              <PerformanceAttribution />
            </div>
            <div class="mt-8">
              <BenchmarkComparison />
            </div>
          </div>

          <!-- Contributions Tab (Phase 2.1) -->
          <ContributionPlanner v-else-if="activeTab === 'contributions'" />

          <!-- Portfolio Optimization Tab -->
          <PortfolioOptimization v-else-if="activeTab === 'optimization'" />

          <!-- Rebalancing Tab -->
          <RebalancingCalculator v-else-if="activeTab === 'rebalancing'" />

          <!-- Goals Tab (Enhanced with Phase 2.3) -->
          <div v-else-if="activeTab === 'goals'">
            <Goals @view-projection="handleViewProjection" />
            <div class="mt-8">
              <GoalProjection />
            </div>
          </div>

          <!-- Tax Efficiency Tab (Phase 2.6) -->
          <div v-else-if="activeTab === 'taxefficiency'">
            <AssetLocationOptimizer />
            <div class="mt-8">
              <WrapperOptimizer />
            </div>
          </div>

          <!-- Fees Tab (Phase 2.5) -->
          <div v-else-if="activeTab === 'fees'">
            <FeeBreakdown />
            <div class="mt-8">
              <FeeSavingsCalculator />
            </div>
          </div>

          <!-- Recommendations Tab -->
          <Recommendations v-else-if="activeTab === 'recommendations'" />
        </div>
      </div>
      </div>
    </div>
  </component>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import AppLayout from '@/layouts/AppLayout.vue';
import PortfolioOverview from '@/components/Investment/PortfolioOverview.vue';
import Accounts from '@/components/Investment/Accounts.vue';
import Holdings from '@/components/Investment/Holdings.vue';
import Performance from '@/components/Investment/Performance.vue';
import Goals from '@/components/Investment/Goals.vue';
import Recommendations from '@/components/Investment/Recommendations.vue';
import TaxFees from '@/components/Investment/TaxFees.vue';
import PortfolioOptimization from '@/components/Investment/PortfolioOptimization.vue';
import RebalancingCalculator from '@/components/Investment/RebalancingCalculator.vue';
import ContributionPlanner from '@/components/Investment/ContributionPlanner.vue';
import AssetLocationOptimizer from '@/components/Investment/AssetLocationOptimizer.vue';
import WrapperOptimizer from '@/components/Investment/WrapperOptimizer.vue';
import PerformanceAttribution from '@/components/Investment/PerformanceAttribution.vue';
import BenchmarkComparison from '@/components/Investment/BenchmarkComparison.vue';
import GoalProjection from '@/components/Investment/GoalProjection.vue';
import FeeBreakdown from '@/components/Investment/FeeBreakdown.vue';
import FeeSavingsCalculator from '@/components/Investment/FeeSavingsCalculator.vue';

export default {
  name: 'InvestmentDashboard',

  components: {
    AppLayout,
    PortfolioOverview,
    Accounts,
    Holdings,
    Performance,
    Goals,
    Recommendations,
    TaxFees,
    PortfolioOptimization,
    RebalancingCalculator,
    ContributionPlanner,
    AssetLocationOptimizer,
    WrapperOptimizer,
    PerformanceAttribution,
    BenchmarkComparison,
    GoalProjection,
    FeeBreakdown,
    FeeSavingsCalculator,
  },

  data() {
    return {
      activeTab: 'overview',
      selectedAccountId: null,
      tabs: [
        { id: 'overview', label: 'Portfolio Overview' },
        { id: 'accounts', label: 'Accounts' },
        { id: 'holdings', label: 'Holdings' },
        { id: 'performance', label: 'Performance' },
        { id: 'contributions', label: 'Contributions' },
        { id: 'optimization', label: 'Portfolio Optimisation' },
        { id: 'rebalancing', label: 'Rebalancing' },
        { id: 'goals', label: 'Goals' },
        { id: 'taxefficiency', label: 'Tax Efficiency' },
        { id: 'fees', label: 'Fees' },
        { id: 'recommendations', label: 'Strategy' },
      ],
    };
  },

  computed: {
    ...mapState('investment', ['loading', 'error']),

    // Check if this component is embedded in another page (like Net Worth)
    isEmbedded() {
      return this.$route.path.startsWith('/net-worth/');
    },
  },

  mounted() {
    this.loadInvestmentData();
  },

  methods: {
    ...mapActions('investment', ['fetchInvestmentData', 'analyseInvestment']),

    async loadInvestmentData() {
      try {
        await this.fetchInvestmentData();
        await this.analyseInvestment();
      } catch (error) {
        console.error('Failed to load investment data:', error);
      }
    },

    openAddAccountModal() {
      // Switch to accounts tab first
      this.activeTab = 'accounts';
      // Wait for next tick to ensure Accounts component is rendered
      this.$nextTick(() => {
        if (this.$refs.accountsComponent && this.$refs.accountsComponent.openAddModal) {
          this.$refs.accountsComponent.openAddModal();
        }
      });
    },

    handleViewHoldings(account) {
      // Store the selected account ID
      this.selectedAccountId = account.id;
      // Switch to holdings tab
      this.activeTab = 'holdings';
    },

    clearAccountFilter() {
      // Clear the selected account filter
      this.selectedAccountId = null;
    },

    navigateToTab(tabId) {
      // Navigate to a specific tab
      this.activeTab = tabId;
    },

    handleViewProjection(goal) {
      // Handle viewing goal projection
      // Could store the selected goal and scroll to GoalProjection component
      console.log('Viewing projection for goal:', goal);
      // Optionally scroll to the GoalProjection component
      this.$nextTick(() => {
        const projectionElement = this.$el.querySelector('.goal-projection');
        if (projectionElement) {
          projectionElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    },
  },
};
</script>

<style scoped>
/* Compact tab navigation for better fit */
.investment-dashboard nav[aria-label="Tabs"] button {
  padding-left: 0.5rem;  /* 8px */
  padding-right: 0.5rem; /* 8px */
  padding-top: 0.5rem;   /* 8px */
  padding-bottom: 0.5rem; /* 8px */
  font-size: 0.8125rem;    /* 13px */
}

/* Mobile optimization for tab navigation */
@media (max-width: 640px) {
  .investment-dashboard nav[aria-label="Tabs"] button {
    font-size: 0.75rem;  /* Slightly smaller on mobile */
    padding-left: 0.5rem;  /* 8px */
    padding-right: 0.5rem; /* 8px */
  }
}

/* Smooth scroll for tab navigation on mobile */
nav[aria-label="Tabs"] {
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}

nav[aria-label="Tabs"]::-webkit-scrollbar {
  display: none;
}
</style>
