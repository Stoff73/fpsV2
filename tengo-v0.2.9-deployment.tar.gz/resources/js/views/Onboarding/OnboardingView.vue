<template>
  <OnboardingWizard />
</template>

<script>
import OnboardingWizard from '@/components/Onboarding/OnboardingWizard.vue';

export default {
  name: 'OnboardingView',

  components: {
    OnboardingWizard,
  },
};
</script>
